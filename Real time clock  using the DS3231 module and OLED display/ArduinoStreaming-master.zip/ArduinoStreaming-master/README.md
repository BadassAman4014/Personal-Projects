# ArduinoStreaming
Arduino Streaming Library (from Mikal Harts site http://arduiniana.org/libraries/streaming/
  <p>I originaly imported this from Mikal's Streaming5.zip @ http://arduiniana.org/Streaming/Streaming5.zip</p>
  <p>All credit goes to him for this <b>amazing</b> code.</p>
